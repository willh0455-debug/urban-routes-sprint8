# data.py
URBAN_ROUTES_URL = "https://cnt-0e38d4e1-fa6d-43fc-920f-cd3378ba6170.containerhub.tripleten-services.com/"
ADDRESS_FROM = "Times Square"
ADDRESS_TO = "Central Park"
PHONE_NUMBER = "+15555550111"
DEFAULT_TIMEOUT = 10
